export function isJidCusFormat(jid: string): boolean {
  return jid?.endsWith('@c.us');
}
