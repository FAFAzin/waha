export function isFromFullSync(event: any): boolean {
  return event.FromFullSync;
}
