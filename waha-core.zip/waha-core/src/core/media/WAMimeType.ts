export enum WAMimeType {
  VOICE = 'audio/ogg; codecs=opus',
  VIDEO = 'video/mp4',
}
