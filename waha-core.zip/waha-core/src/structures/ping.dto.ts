export class PingResponse {
  message: string = 'pong';
}
